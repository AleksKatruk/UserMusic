import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import {ApiService} from "../../../services/api.service";
import {} from '@types/googlemaps';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  public test: any;

  constructor(
    private apiService: ApiService,
    public dialogRef: MatDialogRef<UserDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {
  }

  @ViewChild('gmap') gmapElement: any;
  map: google.maps.Map;
  lat: number = 51.678418;
  lng: number = 7.809007;
  ngOnInit() {
    this.apiService.getAlbum(this.data.user.id).subscribe(item => {
      this.test = item;
      console.log(this.test)
    });
   
  }
}
