import {Component, OnInit, ViewChild} from '@angular/core';
import {ApiService} from "../../services/api.service";
import {MatDialog, MatPaginator, MatTableDataSource} from '@angular/material';
import {UserDetailComponent} from "./user-detail/user-detail.component";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  displayedColumns: string[] = ['name', 'email', 'city', 'street', 'detail'];
  dataSource: any;
  constructor( private apiService: ApiService,
  public dialog: MatDialog){ }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngOnInit() {
    this.apiService.getUsers().subscribe(item => {
      this.dataSource = item;
      this.dataSource.paginator = this.paginator;
    })
  }
  openDialog(elem): void {
    console.log('work');
    const dialogRef = this.dialog.open(UserDetailComponent, {
      width: '550px',
      data: {user: elem}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}
